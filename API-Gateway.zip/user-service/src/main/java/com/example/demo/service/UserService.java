package com.example.demo.service;

import com.example.demo.Entity.User;
import com.example.demo.repository.ResponseDto;

public interface UserService {
    User saveUser(User user);

    ResponseDto getUser(Long userId);
}