package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.User;
import com.example.demo.entity.repo.UserRepository;

@Service
public class UserServiceImpl implements UserService
{
	@Autowired
	private final UserRepository userRepository;
	
	public UserServiceImpl(UserRepository userRepository)
	{
		this.userRepository=userRepository;
	}

	
	public List<User> getAllUsers()
	{
		return userRepository.findAll();
	}

	
	public User getUserById(Long id) {
		// TODO Auto-generated method stub
		return userRepository.findById(id).orElse(null);
	}

	public User getUserByEmail(String email) {
		// TODO Auto-generated method stub
		return userRepository.findByEmail(email);
	}

	
	public void createUser(User user) {
		userRepository.save(user);
		
	}
	
	public void updateUser(Long id, User user) {
		// TODO Auto-generated method stub
		User existingUser = userRepository.findById(id).orElse(null);
		if(existingUser !=null)
		{
			existingUser.setEmail(user.getEmail());
			existingUser.setPassword(user.getPassword());
			userRepository.save(existingUser);
		}
	}

	public void deleteUser(Long id) 
	{
	
	userRepository.deleteById(id);	
	}
}
