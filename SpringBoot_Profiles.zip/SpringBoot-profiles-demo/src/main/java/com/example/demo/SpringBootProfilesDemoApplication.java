package com.example.demo;

import javax.sql.DataSource;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;

import lombok.*;

@SpringBootApplication
@ComponentScan(basePackages="com.example.demo")
public class SpringBootProfilesDemoApplication
{

	
	
	public static void main(String[] args) {
		SpringApplication.run(SpringBootProfilesDemoApplication.class, args);
	}
	
	@Bean
	@Profile("development")
	public DataSource developmentDataSource(Environment environment)
	{
		return DataSourceBuilder.create().url(environment.getProperty("spring.datasource.url"))
				.username(environment.getProperty("spring.datasource.username"))
				.password(environment.getProperty("spring.datasource.password"))
				.build();
	}
	
	@Bean
	@Profile("production")
	public DataSource developmentDataSource1(Environment environment)
	{
		return DataSourceBuilder.create().url(environment.getProperty("spring.datasource.url"))
				.username(environment.getProperty("spring.datasource.username"))
				.password(environment.getProperty("spring.datasource.password"))
				.build();
	}
}
