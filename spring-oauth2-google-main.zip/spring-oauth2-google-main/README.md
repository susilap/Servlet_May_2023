# spring-oauth2-google
Sample project code for Spring Boot OAuth2 Login with Google
### Follow our written tutorial here: [Spring Boot OAuth2 Login with Google Example](https://www.codejava.net/frameworks/spring-boot/oauth2-login-with-google-example)
### Watch coding in action on YouTube: [Spring Boot OAuth2 Social Login with Google Example](https://www.youtube.com/watch?v=lmS0hX5F_QQ)
