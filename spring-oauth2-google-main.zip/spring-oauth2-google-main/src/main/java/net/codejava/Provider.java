package net.codejava;

public enum Provider {
	LOCAL, GOOGLE, FACEBOOK, GITHUB
}
