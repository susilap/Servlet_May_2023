package com.example.demo.service;

import com.example.demo.payload.PaymentRequest;
import com.example.demo.payload.PaymentResponse;

public interface PaymentService {
    long doPayment(PaymentRequest paymentRequest);

    PaymentResponse getPaymentDetailsByOrderId(long orderId);
}
