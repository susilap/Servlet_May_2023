package com.example.demo.controller;

import com.example.demo.payload.request.ProductRequest;
import com.example.demo.payload.response.ProductResponse;
import com.example.demo.service.ProductService;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/product")
@Log4j2
@RequiredArgsConstructor
public class ProductController {

    private final ProductService productService;

    @PostMapping
    public ResponseEntity<Long> addProduct(@RequestBody ProductRequest productRequest) {
        log.info("ProductController | addProduct is called");
        log.info("ProductController | addProduct | productRequest: {}", productRequest);

        long productId = productService.addProduct(productRequest);
        return new ResponseEntity<>(productId, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProductResponse> getProductById(@PathVariable("id") long productId) {
        log.info("ProductController | getProductById is called");
        log.info("ProductController | getProductById | productId: {}", productId);

        ProductResponse productResponse = productService.getProductById(productId);
        return new ResponseEntity<>(productResponse, HttpStatus.OK);
    }

    @PutMapping("/reduceQuantity/{id}")
    public ResponseEntity<Void> reduceQuantity(
            @PathVariable("id") long productId,
            @RequestParam("quantity") long quantity
    ) {
        log.info("ProductController | reduceQuantity is called");
        log.info("ProductController | reduceQuantity | productId: {}", productId);
        log.info("ProductController | reduceQuantity | quantity: {}", quantity);

        productService.reduceQuantity(productId, quantity);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProductById(@PathVariable("id") long productId) {
        productService.deleteProductById(productId);
        return ResponseEntity.noContent().build();
    }
}
