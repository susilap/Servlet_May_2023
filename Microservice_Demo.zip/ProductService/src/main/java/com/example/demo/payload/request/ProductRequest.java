package com.example.demo.payload.request;
import lombok.*;

@Data
@Builder
public class ProductRequest
{
	private String name;
	private long price;
	private long quantity;
}
