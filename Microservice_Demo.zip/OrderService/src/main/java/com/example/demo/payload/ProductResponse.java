package com.example.demo.payload;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ProductResponse {
    private long productId;
    private String productName;
    // Other product-related attributes or fields
    
    public ProductResponse() {
        // Default constructor
    }
    
    public ProductResponse(long productId, String productName) {
        this.productId = productId;
        this.productName = productName;
    }
    
    // Getters and setters for the attributes
    
    @Override
    public String toString() {
        return "ProductResponse{" +
                "productId=" + productId +
                ", productName='" + productName + '\'' +
                // Include other attribute values in the string representation
                '}';
    }
}
