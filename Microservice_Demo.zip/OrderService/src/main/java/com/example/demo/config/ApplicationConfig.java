package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.example.demo.service.external.ProductService;
import com.example.demo.service.external.ProductServiceImpl;
import com.example.demo.service.external.*;
@Configuration
public class ApplicationConfig {

    @Bean
    public ProductService productService() {
        return new ProductServiceImpl();
    }

    // Other bean definitions and configuration
    @Bean
    public PaymentService paymentService() {
        return new PaymentServiceImpl();
    }
    
}
