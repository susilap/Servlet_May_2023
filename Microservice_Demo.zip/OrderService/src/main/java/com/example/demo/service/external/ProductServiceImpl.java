package com.example.demo.service.external;

import com.example.demo.payload.ProductResponse;
import org.springframework.stereotype.Service;

@Service
public class ProductServiceImpl implements ProductService {

    @Override
    public ProductResponse getProductDetails(long productId) {
        // Here, you can implement the logic to fetch product details from your data source
        // For demonstration purposes, a dummy product response is returned

        // Assuming productId 1 corresponds to a product named "Example Product"
        if (productId == 1) {
            return ProductResponse.builder()
                    .productId(productId)
                    .productName("Example Product")
                    .build();
        } else {
            // Return null or throw an exception if the product with the given ID is not found
            return null;
        }
    }
}
