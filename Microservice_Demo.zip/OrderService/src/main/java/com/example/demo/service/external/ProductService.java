package com.example.demo.service.external;

import com.example.demo.payload.ProductResponse;

public interface ProductService {
    ProductResponse getProductDetails(long productId);
}
