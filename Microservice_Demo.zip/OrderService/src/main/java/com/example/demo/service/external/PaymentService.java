package com.example.demo.service.external;

import com.example.demo.payload.PaymentRequest;
import com.example.demo.payload.PaymentResponse;

public interface PaymentService {
    boolean completePayment(PaymentRequest paymentRequest);
    PaymentResponse getPaymentDetails(long orderId);
}
