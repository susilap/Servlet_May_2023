package com.example.demo.service;

import com.example.demo.exception.*;
import com.example.demo.Entity.Order;
import com.example.demo.payload.*;
import com.example.demo.repository.OrderRepository;
import com.example.demo.service.external.ProductService;
import com.example.demo.service.external.PaymentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

import java.time.Instant;

@Service
@Log4j2
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {

    private final OrderRepository orderRepository;
    private final ProductService productService;
    private final PaymentService paymentService;

    @Override
    public long placeOrder(OrderRequest orderRequest) {
        log.info("OrderServiceImpl | placeOrder is called");
        log.info("OrderServiceImpl | placeOrder | Placing Order Request: {}", orderRequest);

        log.info("OrderServiceImpl | placeOrder | Creating Order with Status CREATED");
        Order order = Order.builder()
                .amount(orderRequest.getTotalAmount())
                .orderStatus("CREATED")
                .productId(orderRequest.getProductId())
                .orderDate(Instant.now())
                .quantity(orderRequest.getQuantity())
                .build();

        order = orderRepository.save(order);

        log.info("OrderServiceImpl | placeOrder | Calling Payment Service to complete the payment");

        PaymentRequest paymentRequest = PaymentRequest.builder()
                .orderId(order.getId())
                .paymentMode(orderRequest.getPaymentMode())
                .amount(orderRequest.getTotalAmount())
                .build();

        boolean paymentSuccess = paymentService.completePayment(paymentRequest);

        if (paymentSuccess) {
            log.info("OrderServiceImpl | placeOrder | Payment done successfully. Changing the Order status to PLACED");
            order.setOrderStatus("PLACED");
        } else {
            log.error("OrderServiceImpl | placeOrder | Error occurred in payment. Changing order status to PAYMENT_FAILED");
            order.setOrderStatus("PAYMENT_FAILED");
        }

        orderRepository.save(order);

        log.info("OrderServiceImpl | placeOrder | Order placed successfully with Order Id: {}", order.getId());

        return order.getId();
    }

    @Override
    public OrderResponse getOrderDetails(long orderId) {
        log.info("OrderServiceImpl | getOrderDetails | Get order details for Order Id: {}", orderId);

        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderServiceCustomException("Order not found for the order Id: " + orderId,
                        "NOT_FOUND",
                        404));

        log.info("OrderServiceImpl | getOrderDetails | Invoking Product service to fetch the product for id: {}", order.getProductId());
        ProductResponse productResponse = productService.getProductDetails(order.getProductId());

        log.info("OrderServiceImpl | getOrderDetails | Getting payment information from the payment Service");
        PaymentResponse paymentResponse = paymentService.getPaymentDetails(order.getId());

        OrderResponse.ProductDetails productDetails = OrderResponse.ProductDetails.builder()
                .productName(productResponse.getProductName())
                .productId(productResponse.getProductId())
                .build();

        OrderResponse.PaymentDetails paymentDetails = OrderResponse.PaymentDetails.builder()
                .paymentId(paymentResponse.getPaymentId())
                .paymentStatus(paymentResponse.getPaymentStatus())
                .paymentDate(paymentResponse.getPaymentDate())
                .paymentMode(paymentResponse.getPaymentMode())
                .build();

        OrderResponse orderResponse = OrderResponse.builder()
                .orderId(order.getId())
                .orderStatus(order.getOrderStatus())
                .amount(order.getAmount())
                .orderDate(order.getOrderDate())
                .productDetails(productDetails)
                .paymentDetails(paymentDetails)
                .build();
        
        log.info("OrderServiceImpl | getOrderDetails | orderResponse : " + orderResponse.toString());
        return orderResponse;
}
}