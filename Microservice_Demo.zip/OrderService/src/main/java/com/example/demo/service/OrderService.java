package com.example.demo.service;

import com.example.demo.payload.OrderRequest;
import com.example.demo.payload.OrderResponse;

public interface OrderService {
    long placeOrder(OrderRequest orderRequest);

    OrderResponse getOrderDetails(long orderId);
}