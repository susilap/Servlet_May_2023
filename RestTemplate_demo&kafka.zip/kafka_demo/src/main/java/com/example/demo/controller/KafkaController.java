package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.service.KafkaProducerService;

@RestController
public class KafkaController
{

	private final KafkaProducerService kafkaProducerService;
	
	@Autowired
	public KafkaController(KafkaProducerService kafkaProducerService)
	{
		this.kafkaProducerService = kafkaProducerService;
	}
	
	@PostMapping("/messages")
	public void sendMessage(@RequestBody String message)
	{
		kafkaProducerService.sendMessage(message);
	}
	
}
