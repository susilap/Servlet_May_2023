package com.example.demo.payload.response;

import lombok.*;

@Data
@Builder
@AllArgsConstructor
public class ErrorResponse 
{
private String errorMessage;
private String errorCode;
}
