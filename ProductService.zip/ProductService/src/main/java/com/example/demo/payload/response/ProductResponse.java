package com.example.demo.payload.response;

import lombok.Builder;
import lombok.Data;

@Data
public class ProductResponse 
{
	private String productName;
	private long productId;
	private long quantity;
	private long price;
}
